package flightbookingsystem;

import java.util.Scanner;

public class Ticket extends Flightbookingsystem  {
    
    
    public void genarateTicket() {
             Scanner input = new Scanner(System.in);
   System.out.println( "                                     ");
    System.out.println("NAME: ");
    String name = input.nextLine();
    System.out.println("EMAIL(..John Doe@gmail.com): ");
    String email = input.nextLine();
        System.out.println("SEAT NUMBER: ");
    String seatNo = input.nextLine();
    System.out.println("DESTIINATION: ");
     String destination = input.nextLine();
     System.out.println("ENTER Arrival");
     String arrival = input.nextLine();
     System.out.println("ENTER PAYMENT");
     String payed= input.nextLine();
     System.out.println("ENTER DATE");
     String date= input.nextLine();
    System.out.println("                       ");
    System.out.println("               ESWATINI AIRWAYS           ");
    System.out.println(" ___________________________________ ");
    System.out.println("  NAME         :  "+name);
    System.out.println("  EMAIL    :  "+email);
    System.out.println("  SEAT NO      :  "+seatNo);
    System.out.println("  DESTIINATION :  "+destination);
    System.out.println("  PAYED        :  E"+payed);
    System.out.println("  DATE         :  "+date);
    System.out.println(" ____________________________________ ");
     
      System.out.println("                       ");
     }}

