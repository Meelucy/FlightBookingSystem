package flightbookingsystem;
import java.util.Scanner;

public class Flightbookingsystem {
   public void Menu(){
          int choice;
        do{
        Scanner scanner = new Scanner(System.in);
        System.out.println("======================================== ");
      System.out.println("WELCOME TO ESWATINI AIRWAYS ");
         System.out.println("======================================== ");
           System.out.println(" ");
      
            System.out.println("1. Book Seat");
            System.out.println("2. Display Available Seats");
            System.out.println("3. Do payments");
            System.out.println("4. Check your ticket");
            System.out.println("5. Check available flights");
            System.out.println("6. Log out");
            System.out.println("Enter your choice:");
               choice = scanner.nextInt();
         switch(choice) {
                case 1:
                 Seat s = new Seat();
                 s.Seat(choice);
                 s.bookSeat();
                 
           break;
          
      case 2:
                   Seat m = new Seat();
                   m.cheakAvailableSeats();
                  
                    break;
                case 3:
                  Payment p = new Payment();
                  p.ProcessPayment();
                   
                    break;
                    case 4:
                      Ticket t = new Ticket();
                      t.genarateTicket();
                    break;
                case 5:
                  Flight f = new Flight();
                  f.checkAvailability();
break;
              
             case 6:
                Passenger j= new Passenger();
                j.register();
                    break;
                    
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
      System.out.println(" ");
    } while(choice!=6);}
    

    public static void main(String[] args) {
Passenger a =new Passenger();
        a.register();
        Flightbookingsystem f= new Flightbookingsystem();
        f.Menu();
           
}}
