package flightbookingsystem;

import java.util.Scanner;
public class Seat extends Flightbookingsystem {
    private boolean[] seats;

    public void Seat(int numSeats) {
        seats = new boolean[numSeats];
    }

    
    public void bookSeat() {
        Scanner scanner = new Scanner(System.in);
        
         System.out.println("                       ");
    System.out.println("               ESWATINI AIRWAYS BOOKED SEATS           ");
    System.out.println("   |___________________________________");
       System.out.println("  |----------------|------------------|-------------------|-----------------|");
            System.out.println("  | SEATS A |SEATS B|SEATS C |SEATS D | ");
             System.out.println("  |----------------|-----------------|");
            System.out.println("  | 227      | 111  |   32   |   789 |");
            System.out.println("  | 227      | 111  |   32   |   789 |");
            System.out.println("  | 227      | 111  |   32   |   789 |");
            System.out.println("  | 227      | 111  |   32   |   789 |");            
             System.out.println("  |----------------|------------------|-------------------|-----------------|");
             System.out.println("                                                       ");
        
          System.out.println("Enter seat number to book:");
        int seatNumber = scanner.nextInt();
        

        if(seatNumber < 1 || seatNumber > seats.length) {
            System.out.println("Invalid seat number. Please try again.");
            return;
        }

        if(seats[seatNumber - 1]) {
            System.out.println("Seat " + seatNumber + " is already booked. Please select another seat.");
        } else {
            seats[seatNumber - 1] = true;
            System.out.println("Seat " + seatNumber + " booked successfully.");
        }
    }
 public void cheakAvailableSeats() {
        System.out.println("Available seats:");
        for(int i = 0; i < seats.length; i++) {
            if(!seats[i]) {
                System.out.print((i + 1) + " ");
            }
        }
        System.out.println();
    }

}
