package flightbookingsystem;

import java.util.Scanner;

public class Passenger extends Flightbookingsystem {
    
    public void register(){
      Scanner scanner = new Scanner(System.in);  
         String username;
         String password;
            String Ussername;
         String Paassword;
         
      
  do{
           
    System.out.println("WELCOME TO ESWATINI FLIGHT BOOKING");
    
      System.out.println("________PLEASE REGISTER WITH US________");
    
    System.out.println("Enter Username : ");
    username = scanner.nextLine();
System.out.println("Enter Password : ");
    password = scanner.nextLine();
    
      System.out.println(" ");
       System.out.println(" ");
    
     System.out.println("Registration successful!!");
    
    System.out.println("____SIGN-IN WITH US ____");
     System.out.println("Username : ");
    Ussername = scanner.nextLine();

    
    System.out.println("Password: ");
   Paassword = scanner.nextLine();

    
    
    if (username.equals(Ussername) && password.equals(Paassword)) {

        System.out.println("Access Granted! Welcome "+Ussername );
        System.out.println(" ");
        System.out.println(" ");
        Menu();
        
    }

    else if (username.equals(Ussername)) {
        System.out.println("Invalid Password!");
       
    } else if (password.equals(Paassword)) {
        System.out.println("Invalid Username!");
    } else {
        System.out.println("Invalid Username & Password!");
           
              
    }  
  }while(username!=Ussername&&password!=Paassword);    
   }}
