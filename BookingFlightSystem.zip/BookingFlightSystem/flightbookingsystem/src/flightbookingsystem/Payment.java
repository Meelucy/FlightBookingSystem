package flightbookingsystem;

import java.util.Scanner;

public class Payment extends Flightbookingsystem {
    
     public void ProcessPayment() {
        Scanner input = new Scanner(System.in);
        
         System.out.println("               ESWATINI AIRWAYS           ");
         
       System.out.println( "    ______________________________________________");
       System.out.println("   |        Flight number    |      Ride cost     | ");  
       System.out.println( "   |_________________________|____________________|");
       System.out.println("   |            227          |       E1500        | ");
       System.out.println("   |            456          |       E2000        |");
       System.out.println("   |            326          |       E1800        |");
       System.out.println("   |            773          |       E2200        |");
       System.out.println( "  |_________________________|____________________|");
     System.out.println("enter flight number");
     int flightnumber = input.nextInt();
      
      if(flightnumber ==227){
      System.out.println( "                                     ");
          System.out.println("PLEASE PAY E1500 " );
          System.out.println( "  1. USE SMARTCARD   ");
          System.out.println( "  2. USE VISA   ");
          System.out.println( "Enter method of payment");
          int choice = input.nextInt();
          if(choice ==1){
              
               System.out.println( "PIN: ");
                  int pin = input.nextInt();
               System.out.println( "PAYMENT INPROCESS");
          }
          else if(choice ==2){
               System.out.println( "PAYMENT SUCCESFULY");
          }
         }
         else if(flightnumber ==456){
           System.out.println( "                                     ");
          System.out.println("PLEASE PAY E2000 " );
          System.out.println( "  1. USE CARD   ");
          System.out.println( "  2. USE CASH   ");
          System.out.println( "Enter method of payment");
          int choice = input.nextInt();
          if(choice ==1){
                  System.out.println( "PIN: ");
                 int pin2 = input.nextInt();
               System.out.println( "PAYMENT IN PROCESS...");
          }
          else if(choice ==2){
               System.out.println( "PAYMENT SUCCESFULY...");
              System.out.println( "PRINT TICKET: ");
          }
         }
         else if(flightnumber ==326){
          System.out.println( "                                     ");
          System.out.println("PLEASE PAY E1800 " );
          System.out.println( "  1. USE CARD   ");
          System.out.println( "  2. USE CASH   ");
          System.out.println( "Enter method of payment");int choice = input.nextInt();
          if(choice ==1){
               System.out.println( "PAYMENT INPROCESS");
          }
          else if(choice ==2){
               System.out.println( "PAYMENT SUCCESFULY");
          }
         }
         else if(flightnumber ==773){
          System.out.println( "                                     ");
          System.out.println("PLEASE PAY E2200 " );
          System.out.println( "  1. USE CARD   ");
          System.out.println( "  2. USE CASH   ");
          System.out.println( "Enter method of payment");
          int choice = input.nextInt();
          if(choice ==1){
               System.out.println( "PAYMENT INPROCESS");
          }
          else if(choice ==2){
               System.out.println( "PAYMENT SUCCESFULY");
          }
          System.out.println( "                                     ");
         }
         else{   System.out.println("INVALID ENTRY!!!!! "); 
}
}}
