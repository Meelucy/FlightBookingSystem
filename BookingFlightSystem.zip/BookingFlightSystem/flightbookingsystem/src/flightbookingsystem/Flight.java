package flightbookingsystem;

import java.util.Scanner;

public class Flight extends Flightbookingsystem {
    
    public void checkAvailability() {
     Scanner scanner = new Scanner(System.in);
        System.out.println("                                                       ");
                System.out.println("                 Available flights");
                System.out.println("                                                       ");
             System.out.println("  |----------------|------------------|-------------------|-----------------|");
            System.out.println("  | Flight Number  |     Departure    |    destination    |   Depeture time | ");
             System.out.println("  |----------------|------------------|-------------------|-----------------|");
            System.out.println("  | 1.  H227       |     Eswatini   ->|   Johannesburg    |    0830hrs      |");
            System.out.println("  | 2.  H456       |     Eswatini   ->|   Cape Town       |    1000hrs      |");
            System.out.println("  | 3.  H326       |     Eswatini   ->|   Johannesburg    |    1300hrs      |");
            System.out.println("  | 4.  H773       |     Eswatini   ->|   OR Tambo        |    1500hrs      |");
             System.out.println("  |----------------|------------------|-------------------|-----------------|");
             System.out.println("                                                       ");
                   System.out.println("5. exit");
             
             System.out.println("PLEASE ENTER YOUR CHOICE");
             int choice1 = scanner.nextInt();
         if(choice1 ==1){
           System.out.println("                                                       ");
           System.out.println( "Flight booked succesfuly");
           System.out.println("Your Flight will depeture at  0830hrs" );
            System.out.println( "Please wait patiently for your flight..");
         }
         else if(choice1 ==2){
          System.out.println( "Flight booked succesfuly");
          System.out.println("Your Flight will depeture at  1000hrs " );
           System.out.println( "Please wait patiently for your flight..");
         }
         else if(choice1 ==3){
          System.out.println( "Flight booked succesfuly");
          System.out.println("Your Flight will depeture at  1300hrs " );
           System.out.println( "Please wait patiently for your flight..");
         }
         else if(choice1 ==4){
          System.out.println( "Flight booked succesfuly");
          System.out.println("Your Flight will depeture at  1500hrs " );
           System.out.println( "Please wait patiently for your flight..");
         }
         else if(choice1 ==5){
          System.out.println( "Thank you for your choosing us!!");
        Menu();
         }
         
         
         else{   System.out.println("INVALID ENTRY!!!!! "); 
        
         }

}}
